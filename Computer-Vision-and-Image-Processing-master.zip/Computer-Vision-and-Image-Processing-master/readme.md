Implemented the following modules as a part of CVIP course:
•Mean Shift segmentation.
•Reverse Image Search engine
•Disparity Estimation
•View Synthesis
•Filter application
•Image Histogram.