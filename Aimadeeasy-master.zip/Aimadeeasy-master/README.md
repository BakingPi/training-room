# AI_in_a_nutshell
